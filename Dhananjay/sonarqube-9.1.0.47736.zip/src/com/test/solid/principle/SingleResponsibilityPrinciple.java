package com.test.solid.principle;

public class SingleResponsibilityPrinciple  {

}
