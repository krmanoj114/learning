package com.test.factoryDesign;

public interface OperatingSystemabstractFactory {
	
	public OperatingSystemFactory createOS();

}
