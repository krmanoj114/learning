package com.test.factoryDesign;

public class Android implements OS  {

	public void spec() {
		System.out.println("Most powerful OS");
		
	}

}
