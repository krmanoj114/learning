package com.test.factoryDesign;

public interface OS {
	
	void spec();

}
