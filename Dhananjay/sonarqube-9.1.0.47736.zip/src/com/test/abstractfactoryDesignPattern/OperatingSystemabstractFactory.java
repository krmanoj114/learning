package com.test.abstractfactoryDesignPattern;

public interface OperatingSystemabstractFactory {
	
	public OperatingSystemFactory createOS();

}
