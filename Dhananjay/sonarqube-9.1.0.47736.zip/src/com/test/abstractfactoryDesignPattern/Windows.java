package com.test.abstractfactoryDesignPattern;

public class Windows implements OS{

	public void spec() {
		System.out.println("Other OS");
	}

}
