package com.test.abstractfactoryDesignPattern;

public interface OS {
	
	void spec();

}
