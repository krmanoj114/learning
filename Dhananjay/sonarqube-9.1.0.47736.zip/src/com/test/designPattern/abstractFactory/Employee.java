package com.test.designPattern.abstractFactory;

public interface Employee {
	
	int salary();
	
	String name();

}
