package com.test.designPattern.abstractFactory;

abstract public class EmployeeAbstractFactory {
	public abstract Employee createEmployee();

}
