package com.test.flyweightDesignPatter;

public interface Shap {
	
	public void draw();

}
