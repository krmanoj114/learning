package com.test.java8;

//@FunctionalInterface
public interface InterfaceB extends FunctionalInterfaceTest{
	
	boolean method2();
	
	boolean methood3();

}
