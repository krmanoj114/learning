package com.test.java8;

@FunctionalInterface
public interface FunctionalInterfaceTest {
	
	boolean method();
    default void method1() {
    	
    };

}
