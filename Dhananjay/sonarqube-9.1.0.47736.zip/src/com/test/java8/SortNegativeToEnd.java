package com.test.java8;

import java.util.Arrays;
import java.util.Comparator;

public class SortNegativeToEnd {
	
//	 public static void main(String[] args) {
//		 int[] array = {1, 3, -5, -8, 1, 4};
//
//	        // Use a custom comparator to sort the negative numbers to the end
//	        Arrays.sort(array, new Comparator<Integer>() {
//	            @Override
//	            public int compare(Integer a, Integer b) {
//	                if (a >= 0 && b < 0) {
//	                    return -1; // a comes before b (negative numbers come later)
//	                } else if (a < 0 && b >= 0) {
//	                    return 1; // b comes before a (positive numbers stay in their order)
//	                } else {
//	                    return 0; // Both a and b have the same sign (keep their relative order)
//	                }
//	            }
//	        });
//
//	        // Print the sorted array
//	        for (int num : array) {
//	            System.out.print(num + " ");
//	        }
//	    }

}
