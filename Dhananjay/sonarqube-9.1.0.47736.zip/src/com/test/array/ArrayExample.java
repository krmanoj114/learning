package com.test.array;

public class ArrayExample {
	
	public static void main(String args[]) {
		
		int array[] = new int[4];//declation and instantiation
		
		array[0]= 10;//instantiation
		array[1]= 20;
		array[2]=22;
		array[3]=26;
		
		for(int num: array) {
			System.out.println(num);
		}
		
		
		int array1[]= {33,44,55,66};//declaration,instantiation,initialization
		
		
	}

}
