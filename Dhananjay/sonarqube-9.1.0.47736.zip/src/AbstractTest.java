
abstract class A {
	
	//abstract void method1();
	
	public void method(){
		System.out.println("Hello");
	}
}


public class AbstractTest extends A{
	
	public static void main(String args[]){
		
	}

//	@Override
//	void method1() {
//		// TODO Auto-generated method stub
//		
//	}

}
