
public class test {
	
	public static void main(String args[]){
		
		String a= "RAM";
		
		System.out.println(a);
		
		a = "Shyam";
		
		a.concat("Shyam1");
		
		System.out.println(a);
		
	}

}
