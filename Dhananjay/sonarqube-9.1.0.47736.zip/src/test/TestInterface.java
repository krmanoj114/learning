package test;

public abstract interface TestInterface {
	
	int CONSTANT = 3; 

	public void interfaceMethod(); 
	
//	void method() {
//		
//	}

}

class AB implements TestInterface {

	@Override
	public void interfaceMethod() {
		// TODO Auto-generated method stub
		
	}
	
}
