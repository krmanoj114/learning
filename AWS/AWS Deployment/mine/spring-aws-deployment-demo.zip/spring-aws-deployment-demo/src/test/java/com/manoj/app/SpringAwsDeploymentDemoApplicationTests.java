package com.manoj.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAwsDeploymentDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
