package com.manoj.saga;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SagaChoreographyPatternApplicationTests {

	@Test
	void contextLoads() {
	}

}
